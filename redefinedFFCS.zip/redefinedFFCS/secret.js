module.exports = {

    clientID:'1041308610761-n464nc77oqip396ukj86m69gqb1lmg5b.apps.googleusercontent.com',
    clientSecret:'oK5N7s8GUFoyOCnVXVNLg1yV',
    callbackURL:'/auth/google/redirect',
    cookieSecretKey:"angadsharmaabhirupamitraekaansharora",
    mongoURL:"mongodb://ffcslord:ffcslord@ds012188.mlab.com:12188/ffcs"
}
