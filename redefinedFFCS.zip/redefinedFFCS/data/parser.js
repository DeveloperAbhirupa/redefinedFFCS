const fs = require("fs");
const data = require("./data")


console.log(data.program.bce.pe);
