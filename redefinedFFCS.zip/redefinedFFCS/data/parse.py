f = open("bf.txt","r")
g = open("af.txt","w")

data = f.read()
g.write('[\"')
for i in data:
    if i == '\n':
        g.write('\",\"')

    else:   g.write(i)
g.write("]")
